/**
 * APEX WORKBOOK — API中継Worker (Cloudflare Workers)
 *
 * APIキーをブラウザに晒さずに済ませるための中継サーバーです。
 * 2つのエンドポイントを提供します。
 *
 *   GET /maprotation → マップローテーション（Apex Legends Status）
 *   GET /live        → 配信中のTwitchチャンネル一覧 {"live":["name",...]}
 *   GET /feed        → 配信トレンド（Apex配信中のタイトルからモード・話題語を集計）
 *   GET /rp          → 指定プレイヤーの現在RP（RPトラッカーの自動取得用）
 *                       ?player=名前 または ?uid=数値 ＋ &platform=PC|PS4|X1
 *   GET  /rp-sync?id=復元キー → RANK WORKBOOK の記録をサーバーから取り出す
 *   POST /rp-sync            → RANK WORKBOOK の記録をサーバーへ保存する
 *                              （D1 バインディング RPDB が必要。未設定なら503を返すだけ）
 *
 * ===== 設定するシークレット（Workersの管理画面で設定） =====
 *   APEX_API_KEY        必須  https://api.mozambiquehe.re/getkey で取得
 *   TWITCH_CLIENT_ID    任意  /live を使う場合。Twitch開発者コンソールで取得
 *   TWITCH_CLIENT_SECRET 任意 同上
 *
 * ===== CORS =====
 *   公開データを読むだけのエンドポイントなので、既定では全オリジンを許可します。
 *   自サイトのみに絞りたい場合は STRICT_ORIGINS に配列でドメインを列挙してください。
 *   例: const STRICT_ORIGINS = ["https://suidobashi-y.github.io"];
 */

const STRICT_ORIGINS = [];   // 空配列 = 全オリジン許可

/* 配信中を調べたいTwitchユーザー名（_data.js の twitch と揃える） */
const TWITCH_USERS = [
  "nniru", "shibuyahal", "vodka_", "selly55", "arisaka_", "akamikarubi",
  "hiiragitsurugi", "spygea", "darkmasuotv", "mondo", "euriece", "tie_ru",
  "kawase", "tttcheekyttt", "bobsappaim0304", "kinako_0707", "amakipururu",
  "iq200yukaf", "bijusan", "meltstella", "heshiko1", "satuking_",
  "fps__saku", "4rufq", "lykq8don", "peace_da", "deep_learning_f",
  "hososhin_twitch", "nigongo25", "kanontyandayo", "lstarshunshun",
  "irene28___", "karakaramann", "sawada0117", "chocolate5d",
  "amemiya328", "next_dayo", "mochiyuzu_", "ienaga25", "lullyru11",
  "chitchat_ai", "imperialkaz", "iamfjk", "hoshimai_chill", "sapo_ten",
  "futon_moguri", "hashihimemikona", "amanehina", "89workers",
  "syachikusaku", "d0n__chqn_", "nishimura_honoka", "tsukiyurikira",
  "sigma_e57"
];

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    const origin = request.headers.get("Origin");

    // CORSプリフライト
    if (request.method === "OPTIONS") return cors(new Response(null, { status: 204 }), origin);

    try {
      if (url.pathname === "/maprotation") return cors(await mapRotation(env, ctx), origin);
      if (url.pathname === "/live")        return cors(await live(env, ctx), origin);
      if (url.pathname === "/discover")    return cors(await discover(env, url), origin);
      if (url.pathname === "/feed")        return cors(await feed(request, env, ctx), origin);
      if (url.pathname === "/rp")          return cors(await playerRp(env, url), origin);
      if (url.pathname === "/players")     return cors(await steamPlayers(), origin);
      if (url.pathname === "/rp-sync")     return cors(await rpSync(request, env, url), origin);
      if (url.pathname === "/room")        return cors(await roomApi(request, env, url), origin);
      // ルート: 動作確認用
      if (url.pathname === "/" ) return cors(json({
        ok: true,
        endpoints: ["/maprotation", "/live", "/discover", "/feed", "/rp", "/players", "/rp-sync", "/room"],
        apexKey: env.APEX_API_KEY ? "設定済み" : "未設定",
        twitch: (env.TWITCH_CLIENT_ID && env.TWITCH_CLIENT_SECRET) ? "設定済み" : "未設定",
        d1: env.RPDB ? "設定済み" : "未設定"
      }), origin);
      return cors(json({ error: "Not found" }, 404), origin);
    } catch (e) {
      return cors(json({ error: String(e.message || e) }, 502), origin);
    }
  }
};

/* ---------- マップローテーション ---------- */
async function mapRotation(env, ctx) {
  if (!env.APEX_API_KEY) return json({ error: "APEX_API_KEY が未設定です" }, 500);

  const upstream = "https://api.mozambiquehe.re/maprotation?version=2&auth=" + env.APEX_API_KEY;
  // 60秒キャッシュ（上流のレート制限対策）
  const res = await fetch(upstream, { cf: { cacheTtl: 60, cacheEverything: true } });
  if (!res.ok) return json({ error: "upstream " + res.status }, 502);

  const data = await res.json();
  return json(data, 200, 60);
}

/* ---------- プレイヤーの現在RP（RPトラッカー用） ---------- */
/* 例: /rp?player=Zume&platform=X1          → 名前で検索
 *     /rp?uid=2535428181264092&platform=X1 → UIDで検索（名前変更に強い）
 * 応答: {"rp":14820,"tier":"Platinum","div":1,"uid":"...","at":...}
 */
const RP_PLATFORMS = ["PC", "PS4", "X1"];

async function playerRp(env, url) {
  if (!env.APEX_API_KEY) return json({ error: "APEX_API_KEY が未設定です" }, 500);

  const player   = (url.searchParams.get("player") || "").trim();
  const uid      = (url.searchParams.get("uid") || "").trim();
  const platform = url.searchParams.get("platform") || "X1";

  if (!RP_PLATFORMS.includes(platform)) {
    return json({ error: "platform は PC / PS4 / X1 のいずれかです" }, 400);
  }
  if (!player && !uid) return json({ error: "player または uid が必要です" }, 400);
  if (player.length > 40 || uid.length > 40) return json({ error: "指定が長すぎます" }, 400);

  const q = uid
    ? "uid=" + encodeURIComponent(uid)
    : "player=" + encodeURIComponent(player);

  const upstream = "https://api.mozambiquehe.re/bridge?version=5&auth=" + env.APEX_API_KEY +
                   "&platform=" + platform + "&" + q;

  const res  = await fetch(upstream, { cf: { cacheTtl: 90, cacheEverything: true } });
  const text = await res.text();

  let data = null;
  try { data = JSON.parse(text); } catch (e) { /* JSONでない応答 */ }

  // 上流エラーは中身をそのまま見せる（原因切り分け用）
  if (!res.ok || (data && data.Error)) {
    return json({
      error:  res.status === 404 ? "not-found" : "upstream",
      status: res.status,
      detail: (data && (data.Error || data.message)) || text.slice(0, 200),
      hint:   "EA名（PCはEAアカウント名、PS/Xboxはオンラインで表示される名前）とplatformの組み合わせを確認してください"
    }, res.status === 404 ? 404 : 502);
  }

  const rank = data && data.global && data.global.rank;
  if (!rank) {
    return json({ error: "no-rank", detail: "ランク情報が含まれていません", raw: Object.keys(data || {}) }, 404);
  }

  return json({
    rp:   typeof rank.rankScore === "number" ? rank.rankScore : null,
    tier: rank.rankName || null,
    div:  rank.rankDiv ?? null,
    uid:  (data.global && data.global.uid) || null,
    name: (data.global && data.global.name) || null,
    at:   Date.now()
  }, 200, 90);
}

/* ---------- 配信中のTwitchチャンネル ----------
   返すもの:
     live    配信中のユーザー名（ゲーム問わず）
     apex    そのうち Apex Legends を配信中のユーザー名
     games   {ユーザー名: {id, name}}  配信中のゲーム
     titles  {ユーザー名: 配信タイトル}
     viewers {ユーザー名: 視聴者数}
     icons   {ユーザー名: プロフィール画像URL}（リスト全員分）      */
const APEX_GAME_ID = "511224";   // Apex Legends

async function live(env, ctx) {
  const id = env.TWITCH_CLIENT_ID, secret = env.TWITCH_CLIENT_SECRET;
  if (!id || !secret) return json({ live: [], apex: [], note: "Twitchの認証情報が未設定です" }, 200, 60);

  // アプリトークンを取得（60秒キャッシュ）
  const tokRes = await fetch("https://id.twitch.tv/oauth2/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: id, client_secret: secret, grant_type: "client_credentials"
    }),
    cf: { cacheTtl: 3000, cacheEverything: true }
  });
  if (!tokRes.ok) return json({ error: "twitch auth " + tokRes.status }, 502);
  const token = (await tokRes.json()).access_token;

  const head = { "Client-ID": id, "Authorization": "Bearer " + token };

  // --- 配信中の情報（user_login は1リクエスト100件まで） ---
  const liveNames = [], apexNames = [];
  const games = {}, titles = {}, viewers = {};

  for (let i = 0; i < TWITCH_USERS.length; i += 100) {
    const q = new URLSearchParams();
    TWITCH_USERS.slice(i, i + 100).forEach(u => q.append("user_login", u));
    q.append("first", "100");
    const r = await fetch("https://api.twitch.tv/helix/streams?" + q, {
      headers: head,
      cf: { cacheTtl: 60, cacheEverything: true }
    });
    if (!r.ok) continue;
    const j = await r.json();
    (j.data || []).forEach(s => {
      const login = (s.user_login || "").toLowerCase();
      if (!login) return;
      liveNames.push(login);
      games[login]   = { id: s.game_id || "", name: s.game_name || "" };
      titles[login]  = s.title || "";
      viewers[login] = s.viewer_count || 0;
      if (String(s.game_id) === APEX_GAME_ID) apexNames.push(login);
    });
  }

  // 視聴者数の多い順
  apexNames.sort((a, b) => (viewers[b] || 0) - (viewers[a] || 0));

  // --- プロフィール画像（オフラインの人も含めリスト全員分） ---
  const icons = {};
  for (let i = 0; i < TWITCH_USERS.length; i += 100) {
    const q = new URLSearchParams();
    TWITCH_USERS.slice(i, i + 100).forEach(u => q.append("login", u));
    const r = await fetch("https://api.twitch.tv/helix/users?" + q, {
      headers: head,
      cf: { cacheTtl: 3600, cacheEverything: true }
    });
    if (!r.ok) continue;
    const j = await r.json();
    (j.data || []).forEach(u => {
      if (u.login && u.profile_image_url) icons[u.login.toLowerCase()] = u.profile_image_url;
    });
  }

  return json({
    live: liveNames, apex: apexNames,
    games, titles, viewers, icons,
    updated: new Date().toISOString()
  }, 200, 60);
}

/* ---------- 配信者の発掘（リスト追加候補を探す） ----------
   GET /discover                 視聴者20人以上の日本語Apex配信を視聴者数順に
   GET /discover?min=5&max=300   視聴者数の範囲を指定
   GET /discover?all=1           既にリストにいる人も含める
   ブラウザで開いて、追加したい人の login をコピーして data.js と TWITCH_USERS に貼ってください。 */
async function discover(env, url) {
  const id = env.TWITCH_CLIENT_ID, secret = env.TWITCH_CLIENT_SECRET;
  if (!id || !secret) return json({ error: "Twitchの認証情報が未設定です" }, 500);

  const min = Number(url.searchParams.get("min") || 20);
  const max = Number(url.searchParams.get("max") || 1000000);
  const includeAll = url.searchParams.get("all") === "1";

  const token = await twitchToken(id, secret);
  const head = { "Client-ID": id, "Authorization": "Bearer " + token };
  const known = new Set(TWITCH_USERS.map(u => u.toLowerCase()));

  // 日本語のApex配信を最大300件（3ページ）
  const found = [];
  let cursor = "";
  for (let page = 0; page < 3; page++) {
    const q = new URLSearchParams({
      game_id: APEX_GAME_ID, language: "ja", first: "100"
    });
    if (cursor) q.append("after", cursor);
    const r = await fetch("https://api.twitch.tv/helix/streams?" + q, {
      headers: head, cf: { cacheTtl: 60, cacheEverything: true }
    });
    if (!r.ok) break;
    const j = await r.json();
    (j.data || []).forEach(s => {
      const login = (s.user_login || "").toLowerCase();
      if (!login) return;
      if (!includeAll && known.has(login)) return;
      if (s.viewer_count < min || s.viewer_count > max) return;
      found.push({
        name:    s.user_name,          // data.js の name にそのまま使えます
        twitch:  login,                // data.js の twitch / TWITCH_USERS 用
        viewers: s.viewer_count,
        title:   s.title,
        url:     "https://www.twitch.tv/" + login
      });
    });
    cursor = j.pagination && j.pagination.cursor;
    if (!cursor) break;
  }

  found.sort((a, b) => b.viewers - a.viewers);

  // そのまま data.js に貼れる形も添える
  const snippet = found.map(s =>
    `  {name:"${s.name}", twitch:"${s.twitch}", tw:0, tags:["rank"]},`
  ).join("\n");

  return json({
    count: found.length,
    filter: { min, max, excludeKnown: !includeAll },
    candidates: found,
    dataJsSnippet: snippet,
    twitchUsersSnippet: found.map(s => `"${s.twitch}"`).join(", "),
    updated: new Date().toISOString()
  }, 200, 60);
}

/* ---------- 配信トレンド ----------
   GET /feed
     登録配信者のうち Apex を配信中の人のタイトルを解析し、
     「いま日本の上位層が何をやっているか」を返す。

     modes   モードの内訳（ランク / カジュアル / 大会・スクリム など）
             人数と視聴者数の両方で集計する。少人数でも視聴者が多ければ
             そちらのほうが「話題」に近いため。
     terms   レジェンド・武器・ランク帯の言及。普段はまばらだが、
             特定の語が跳ねたときがシグナルになる。
     streams 視聴者数の多い順の実配信（10件）

   Reddit / Google News は Worker からのアクセスが遮断されるため取りやめ。
   こちらは既存の Twitch 認証をそのまま使うので追加のキーは不要。      */

const FEED_TTL = 300;   // 5分キャッシュ（配信は入れ替わりが速い）

/* モード判定。上から順に評価し、最初に当たったものを採用する */
const FEED_MODES = [
  { key: "大会・スクリム", words: ["大会", "スクリム", "カスタム", "scrim", "algs", "予選", "本戦"] },
  { key: "ランク",        words: ["ランク", "らんく", "ランクマ", "rank", "ソロランク", "デュオランク"] },
  { key: "参加型",        words: ["参加型", "視聴者参加", "参加者募集", "コーチング"] },
  { key: "練習・検証",    words: ["射撃訓練", "練習", "検証", "エイム", "aim", "感度"] },
  { key: "カジュアル",    words: ["カジュアル", "カジュ", "ミックステープ", "アリーナ", "デュオ", "トリオ"] }
];

/* 話題語。ここを増やせば拾える語が増える */
const FEED_TERMS = [
  // ランク帯
  { key: "プレデター", cat: "tier",   words: ["プレデター", "プレデタ", "pred"] },
  { key: "マスター",   cat: "tier",   words: ["マスター", "master"] },
  { key: "ダイヤ",     cat: "tier",   words: ["ダイヤ", "diamond"] },
  { key: "プラチナ",   cat: "tier",   words: ["プラチナ", "プラチナ帯", "plat"] },
  // 武器（S30 の調整対象を中心に）
  { key: "RE-45",      cat: "weapon", words: ["re-45", "re45", "アールイー"] },
  { key: "ボルト",     cat: "weapon", words: ["ボルト", "volt"] },
  { key: "ネメシス",   cat: "weapon", words: ["ネメシス", "nemesis"] },
  { key: "フラットライン", cat: "weapon", words: ["フラットライン", "フラトラ", "flatline"] },
  { key: "R-301",      cat: "weapon", words: ["r-301", "r301", "サンマルイチ"] },
  { key: "ウィングマン", cat: "weapon", words: ["ウィングマン", "wingman"] },
  { key: "R-99",       cat: "weapon", words: ["r-99", "r99"] },
  { key: "ハボック",   cat: "weapon", words: ["ハボック", "havoc"] },
  { key: "ヘムロック", cat: "weapon", words: ["ヘムロック", "hemlok"] },
  { key: "クレーバー", cat: "weapon", words: ["クレーバー", "kraber"] },
  // レジェンド（使用率の高い順に絞って掲載）
  { key: "アッシュ",   cat: "legend", words: ["アッシュ", "ash"] },
  { key: "ブラッドハウンド", cat: "legend", words: ["ブラッドハウンド", "ブラハ", "bloodhound"] },
  { key: "パスファインダー", cat: "legend", words: ["パスファインダー", "パスファ", "pathfinder"] },
  { key: "オクタン",   cat: "legend", words: ["オクタン", "octane"] },
  { key: "レイス",     cat: "legend", words: ["レイス", "wraith"] },
  { key: "ホライゾン", cat: "legend", words: ["ホライゾン", "horizon"] },
  { key: "カタリスト", cat: "legend", words: ["カタリスト", "catalyst"] },
  { key: "ニューキャッスル", cat: "legend", words: ["ニューキャッスル", "ニューキャ", "newcastle"] },
  { key: "コースティック", cat: "legend", words: ["コースティック", "カスティ", "caustic"] },
  { key: "ジブラルタル", cat: "legend", words: ["ジブラルタル", "ジブ", "gibraltar"] },
  // 仕様・話題
  { key: "エネルギー弾", cat: "topic", words: ["エネルギー弾", "エネルギー"] },
  { key: "ルート",     cat: "topic",  words: ["ルート", "loot", "漁り"] },
  { key: "新シーズン", cat: "topic",  words: ["シーズン30", "s30", "新シーズン", "アプデ", "パッチ"] }
];

async function feed(request, env, ctx) {
  const cache = caches.default;
  const key = new Request(new URL(request.url).toString(), { method: "GET" });
  const hit = await cache.match(key);
  if (hit) return hit;

  const id = env.TWITCH_CLIENT_ID, secret = env.TWITCH_CLIENT_SECRET;
  if (!id || !secret) return json({ ok: false, error: "Twitchの認証情報が未設定です" }, 200, 60);

  let streams = [];
  try {
    const token = await twitchToken(id, secret);
    const head = { "Client-ID": id, "Authorization": "Bearer " + token };

    for (let i = 0; i < TWITCH_USERS.length; i += 100) {
      const q = new URLSearchParams();
      TWITCH_USERS.slice(i, i + 100).forEach(u => q.append("user_login", u));
      q.append("first", "100");
      const r = await fetch("https://api.twitch.tv/helix/streams?" + q, {
        headers: head,
        cf: { cacheTtl: 60, cacheEverything: true }
      });
      if (!r.ok) continue;
      const j = await r.json();
      (j.data || []).forEach(st => {
        if (String(st.game_id) !== APEX_GAME_ID) return;   // Apex 以外は除外
        streams.push({
          login:   (st.user_login || "").toLowerCase(),
          name:    st.user_name || "",
          title:   st.title || "",
          viewers: st.viewer_count || 0,
          startedAt: st.started_at || null
        });
      });
    }
  } catch (e) {
    return json({ ok: false, error: String(e.message || e) }, 200, 60);
  }

  streams.sort((a, b) => b.viewers - a.viewers);
  const totalViewers = streams.reduce((n, s) => n + s.viewers, 0);

  // --- モードの内訳 ---
  const modes = {};
  for (const st of streams) {
    const t = feedNorm(st.title);
    let hitKey = "その他";
    for (const m of FEED_MODES) {
      if (m.words.some(w => t.includes(feedNorm(w)))) { hitKey = m.key; break; }
    }
    if (!modes[hitKey]) modes[hitKey] = { key: hitKey, streams: 0, viewers: 0 };
    modes[hitKey].streams++;
    modes[hitKey].viewers += st.viewers;
  }
  const modeList = Object.values(modes).sort((a, b) => b.viewers - a.viewers);

  // --- 話題語の言及 ---
  const terms = [];
  for (const term of FEED_TERMS) {
    let n = 0, v = 0; const who = [];
    for (const st of streams) {
      const t = feedNorm(st.title);
      if (term.words.some(w => t.includes(feedNorm(w)))) {
        n++; v += st.viewers;
        if (who.length < 3) who.push(st.name || st.login);
      }
    }
    if (n > 0) terms.push({ key: term.key, cat: term.cat, streams: n, viewers: v, who });
  }
  terms.sort((a, b) => b.viewers - a.viewers);

  const res = json({
    ok: true,
    generatedAt: new Date().toISOString(),
    summary: {
      tracked: TWITCH_USERS.length,
      apexLive: streams.length,
      totalViewers
    },
    modes: modeList,
    terms,
    streams: streams.slice(0, 10)
  }, 200, FEED_TTL);

  if (ctx && ctx.waitUntil) ctx.waitUntil(cache.put(key, res.clone()));
  return res;
}

/* 全角・大小・記号のゆれを吸収してから照合する。
   長音符「ー」はハイフンに変換しないこと。変換すると
   「エネルギー」→「エネルギ-」となり辞書側と一致しなくなる。 */
function feedNorm(s) {
  return (s || "")
    .toLowerCase()
    .replace(/[Ａ-Ｚａ-ｚ０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xFEE0))
    .replace(/[‐‑‒–—―]/g, "-")
    .replace(/[\s　]+/g, "");
}

/* ---------- ヘルパー ---------- */
async function twitchToken(id, secret) {
  const res = await fetch("https://id.twitch.tv/oauth2/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: id, client_secret: secret, grant_type: "client_credentials"
    }),
    cf: { cacheTtl: 3000, cacheEverything: true }
  });
  if (!res.ok) throw new Error("twitch auth " + res.status);
  return (await res.json()).access_token;
}

/* ---------- Steam同時接続数（Apex / appid 1172470） ---------- */
const STEAM_APPID = "1172470";

async function steamPlayers() {
  const upstream =
    "https://api.steampowered.com/ISteamUserStats/GetNumberOfCurrentPlayers/v1/?appid=" + STEAM_APPID;

  // Cloudflare側で60秒キャッシュ。Steamへの実リクエストは毎分1回に抑える
  const res = await fetch(upstream, { cf: { cacheTtl: 60, cacheEverything: true } });
  if (!res.ok) return json({ error: "Steam API error: " + res.status }, 502);

  const data = await res.json();
  const n = data && data.response && data.response.player_count;
  if (typeof n !== "number") return json({ error: "unexpected Steam response" }, 502);

  return json({
    player_count: n,
    appid: STEAM_APPID,
    fetched_at: new Date().toISOString()
  }, 200, 60);
}

/* =========================================================
   RANK WORKBOOK のサーバー保存（Cloudflare D1）

   Safari の ITP は7日開かないと localStorage を消してしまうため、
   端末内だけの保存では記録が失われる。ここではログイン不要のまま、
   利用者が控えておける12文字の「復元キー」を主キーにして記録を預かる。

   保存するもの : 日付 / RP / 取得元 / ティア / 当日ログ / プラットフォーム / 目標
   保存しないもの: EA名・UID（個人が特定されうるものは受け取らない）

   バインディング: wrangler.toml の [[d1_databases]] で binding = "RPDB"
   未設定でも他のエンドポイントは動く（このエンドポイントだけ503を返す）
   ========================================================= */

const RPS_MAX_DAYS = 400;   // 1回に受け取る最大日数
const RPS_CHUNK    = 50;    // batch の分割サイズ
const RPS_KEY_RE   = /^[0-9A-HJKMNP-TV-Z]{12}$/;   // Crockford Base32（I L O U を除く）

/* 打ち間違えやすい文字を吸収してから検証する */
function rpsKey(v) {
  const t = String(v || "").toUpperCase().replace(/[^0-9A-Z]/g, "")
    .replace(/[IL]/g, "1").replace(/O/g, "0");
  return RPS_KEY_RE.test(t) ? t : null;
}
const rpsStr = (v, n) => (v === null || v === undefined || v === "") ? null : String(v).slice(0, n);
const rpsInt = (v) => Number.isFinite(Number(v)) ? Math.round(Number(v)) : null;
function rpsParse(s) { try { return JSON.parse(s); } catch (e) { return undefined; } }

/* テーブルは初回アクセス時に作る（管理画面でSQLを流さなくてよい） */
let rpsReady = null;
function rpsInit(db) {
  if (!rpsReady) {
    rpsReady = db.batch([
      db.prepare(`CREATE TABLE IF NOT EXISTS rp_log (
        anon_id TEXT    NOT NULL,
        day     TEXT    NOT NULL,
        rp      INTEGER NOT NULL,
        src     TEXT,
        tier    TEXT,
        div     INTEGER,
        log     TEXT,
        at      INTEGER NOT NULL,
        PRIMARY KEY (anon_id, day)
      )`),
      db.prepare(`CREATE TABLE IF NOT EXISTS rp_profile (
        anon_id  TEXT PRIMARY KEY,
        platform TEXT,
        goal_t   TEXT,
        goal_d   INTEGER,
        at       INTEGER NOT NULL,
        seen_at  INTEGER NOT NULL
      )`),
      /* ランクルームの座席。room_id は復元キーそのものではなく、
         端末側でハッシュして作った別ID（下の解説を参照）。 */
      db.prepare(`CREATE TABLE IF NOT EXISTS room_seat (
        room_id   TEXT PRIMARY KEY,
        seat_no   INTEGER NOT NULL,
        pub       TEXT,
        handle    TEXT,
        tier      TEXT,
        rp        INTEGER,
        last_seen INTEGER NOT NULL
      )`),
      /* 1席1人を DB 側で保証する。入れ替えで一時退避が要るのはこの制約のため。 */
      db.prepare(`CREATE UNIQUE INDEX IF NOT EXISTS room_seat_no ON room_seat(seat_no)`)
    ]).catch(e => { rpsReady = null; throw e; });
  }
  return rpsReady;
}

async function rpsBatch(db, stmts) {
  for (let i = 0; i < stmts.length; i += RPS_CHUNK) {
    await db.batch(stmts.slice(i, i + RPS_CHUNK));
  }
}

async function rpSync(request, env, url) {
  const db = env.RPDB;
  if (!db) return json({ error: "d1-unbound" }, 503);
  await rpsInit(db);

  /* ---- 取り出し ---- */
  if (request.method === "GET") {
    const id = rpsKey(url.searchParams.get("id"));
    if (!id) return json({ error: "bad-id" }, 400);

    const rows = await db.prepare(
      "SELECT day, rp, src, tier, div, log, at FROM rp_log WHERE anon_id = ?1 ORDER BY day"
    ).bind(id).all();
    const prof = await db.prepare(
      "SELECT platform, goal_t, goal_d, at FROM rp_profile WHERE anon_id = ?1"
    ).bind(id).first();

    return json({
      ok: true,
      days: (rows.results || []).map(r => ({
        day: r.day, rp: r.rp, src: r.src || undefined, tier: r.tier || undefined,
        div: (r.div === null || r.div === undefined) ? undefined : r.div,
        log: r.log ? rpsParse(r.log) : undefined,
        at: r.at
      })),
      profile: prof ? {
        platform: prof.platform || null,
        goal: prof.goal_t ? { t: prof.goal_t, d: prof.goal_d || 0 } : null,
        at: prof.at
      } : null
    });
  }

  if (request.method !== "POST") return json({ error: "method-not-allowed" }, 405);

  let body;
  try { body = await request.json(); } catch (e) { return json({ error: "bad-json" }, 400); }
  const id = rpsKey(body && body.id);
  if (!id) return json({ error: "bad-id" }, 400);

  const now = Date.now();

  /* ---- 全消去（トラッカー側の「すべての記録を削除」から） ---- */
  if (body.wipe === true) {
    await db.batch([
      db.prepare("DELETE FROM rp_log WHERE anon_id = ?1").bind(id),
      db.prepare("DELETE FROM rp_profile WHERE anon_id = ?1").bind(id)
    ]);
    return json({ ok: true, wiped: true });
  }

  /* ---- 保存（at が新しい方を残す＝古い端末が上書きしない） ---- */
  const list  = Array.isArray(body.days) ? body.days.slice(0, RPS_MAX_DAYS) : [];
  const stmts = [];
  const up = db.prepare(
    `INSERT INTO rp_log (anon_id, day, rp, src, tier, div, log, at)
     VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)
     ON CONFLICT(anon_id, day) DO UPDATE SET
       rp = excluded.rp, src = excluded.src, tier = excluded.tier,
       div = excluded.div, log = excluded.log, at = excluded.at
     WHERE excluded.at > rp_log.at`
  );

  let saved = 0;
  for (const d of list) {
    if (!d || !/^\d{4}-\d{2}-\d{2}$/.test(String(d.day || ""))) continue;
    const rp = Math.round(Number(d.rp));
    if (!Number.isFinite(rp) || rp < 0 || rp > 100000) continue;
    const at = (Number(d.at) > 0) ? Math.min(Number(d.at), now + 864e5) : now;

    let log = null;
    if (Array.isArray(d.log) && d.log.length) {
      log = JSON.stringify(d.log.slice(-30).map(x => ({
        rp: Math.round(Number(x && x.rp)) || 0,
        src: rpsStr(x && x.src, 8),
        at: Number(x && x.at) || null
      })));
      if (log.length > 4000) log = null;
    }
    stmts.push(up.bind(id, d.day, rp, rpsStr(d.src, 8), rpsStr(d.tier, 16), rpsInt(d.div), log, at));
    saved++;
  }

  const p = body.profile;
  if (p && typeof p === "object") {
    stmts.push(db.prepare(
      `INSERT INTO rp_profile (anon_id, platform, goal_t, goal_d, at, seen_at)
       VALUES (?1, ?2, ?3, ?4, ?5, ?6)
       ON CONFLICT(anon_id) DO UPDATE SET
         platform = excluded.platform, goal_t = excluded.goal_t,
         goal_d = excluded.goal_d, at = excluded.at, seen_at = excluded.seen_at
       WHERE excluded.at >= rp_profile.at`
    ).bind(id, rpsStr(p.platform, 8),
              p.goal ? rpsStr(p.goal.t, 16) : null,
              p.goal ? rpsInt(p.goal.d) : null,
              (Number(p.at) > 0) ? Number(p.at) : now, now));
  } else {
    stmts.push(db.prepare(
      `INSERT INTO rp_profile (anon_id, platform, goal_t, goal_d, at, seen_at)
       VALUES (?1, NULL, NULL, NULL, 0, ?2)
       ON CONFLICT(anon_id) DO UPDATE SET seen_at = excluded.seen_at`
    ).bind(id, now));
  }

  await rpsBatch(db, stmts);
  return json({ ok: true, saved });
}

/* =========================================================
   ランクルーム（/room）

   記録中の人が席に着き、部屋として見える機能。room.html から使う。

   ■ なぜ復元キーをそのまま使わないか
   復元キーは「知っていれば全記録が読める」読み取り認証情報。
   ルームは公開エンドポイントなので、ここにキーを流すと
   経路のどこかで漏れたときに RP 履歴ごと持っていかれる。
   そこで端末側で SHA-256 して別IDを2本作り、キー本体は送らない。
     room_id … 席の所有者確認に使う（サーバーには来るが公開しない）
     pub     … 画面に出す4文字（PLAYER 8C21 の部分）
   別ソルトで導出しているので、pub から room_id は逆算できない。

   ■ 在室の判定
   last_seen が 30分以内 = live / 4時間以内 = ghost / それ以上は削除。
   ========================================================= */

const ROOM_SEATS    = 12;
const ROOM_LIVE_MS  = 30 * 60 * 1000;
const ROOM_GHOST_MS = 4 * 60 * 60 * 1000;
const ROOM_ID_RE    = /^[0-9A-HJKMNP-TV-Z]{12}$/;
const ROOM_PUB_RE   = /^[0-9A-HJKMNP-TV-Z]{4}$/;
const ROOM_HDL_RE   = /^[A-Za-z0-9_]{1,15}$/;
const ROOM_TIERS    = ["pred","mas","dia","pla","gld","slv","brz","roo"];

const roomId  = v => ROOM_ID_RE.test(String(v || "").toUpperCase())  ? String(v).toUpperCase() : null;
const roomPub = v => ROOM_PUB_RE.test(String(v || "").toUpperCase()) ? String(v).toUpperCase() : null;
const roomTier = v => ROOM_TIERS.includes(String(v)) ? String(v) : null;
/* 他人の画面に出る文字列なので、ここを通らないものは保存しない */
function roomHandle(v) {
  /* 未指定(undefined)と空文字はどちらも null にする。
     sit では「今の値を保つ」、handle では「表示しない」の意味になる。 */
  if (v === undefined || v === null || v === "") return null;
  const t = String(v).replace(/^@/, "");
  return ROOM_HDL_RE.test(t) ? t : undefined;   // undefined = 不正
}
const roomRp = v => Number.isFinite(Number(v)) ? Math.max(0, Math.min(99999, Math.round(Number(v)))) : null;

/* 期限切れの席を落とす。読むたびに流すので cron は要らない */
function roomSweep(db, now) {
  return db.prepare("DELETE FROM room_seat WHERE last_seen < ?1").bind(now - ROOM_GHOST_MS).run();
}

async function roomRows(db) {
  const r = await db.prepare(
    "SELECT room_id, seat_no, pub, handle, tier, rp, last_seen FROM room_seat WHERE seat_no > 0"
  ).all();
  return r.results || [];
}

/* room_id は絶対に返さない */
function roomView(rows, now, meId) {
  let live = 0, ghost = 0, me = 0;
  const seats = rows.map(r => {
    const age = now - r.last_seen;
    const st  = age < ROOM_LIVE_MS ? "live" : "ghost";
    if (st === "live") live++; else ghost++;
    if (meId && r.room_id === meId) me = r.seat_no;
    return { n: r.seat_no, st, pub: r.pub, h: r.handle, tier: r.tier, rp: r.rp, age: Math.round(age / 1000) };
  }).sort((a, b) => a.n - b.n);
  return { ok: true, seats, total: ROOM_SEATS, live, ghost, me };
}

async function roomApi(request, env, url) {
  const db = env.RPDB;
  if (!db) return json({ error: "d1-unbound" }, 503);
  await rpsInit(db);
  const now = Date.now();
  await roomSweep(db, now);

  /* ---- 読み取り ---- */
  if (request.method === "GET") {
    const id = roomId(url.searchParams.get("id"));

    /* tracker のウィジェット用。人数だけを返す軽い経路 */
    if (url.searchParams.get("count")) {
      const rows = await roomRows(db);
      const v = roomView(rows, now, null);
      return json({ ok: true, live: v.live, ghost: v.ghost, total: ROOM_SEATS });
    }

    /* hb=1 のときだけ在室を延長する。
       ただの閲覧で延長すると「記録中の人の部屋」でなくなるため、
       room.html は画面が見えている間だけ hb を送る。 */
    if (id && url.searchParams.get("hb")) {
      await db.prepare("UPDATE room_seat SET last_seen = ?2 WHERE room_id = ?1").bind(id, now).run();
    }
    return json(roomView(await roomRows(db), now, id));
  }

  if (request.method !== "POST") return json({ error: "method" }, 405);

  const body = await request.json().catch(() => ({}));
  const id   = roomId(body.id);
  if (!id) return json({ error: "bad-id" }, 400);
  const act  = String(body.act || "sit");

  const mineRow = await db.prepare(
    "SELECT seat_no, pub, handle, tier, rp FROM room_seat WHERE room_id = ?1"
  ).bind(id).first();

  /* ---- 離席 ---- */
  if (act === "leave") {
    /* 行は消さない。4時間はゴーストとして残り、戻れば同じ席に座り直せる */
    await db.prepare("UPDATE room_seat SET last_seen = ?2 WHERE room_id = ?1")
      .bind(id, now - ROOM_LIVE_MS - 1000).run();
    return json(roomView(await roomRows(db), now, id));
  }

  /* ---- ハンドルの設定・解除 ---- */
  if (act === "handle") {
    const h = roomHandle(body.handle);
    if (h === undefined) return json({ error: "bad-handle" }, 400);
    if (!mineRow) return json({ error: "not-seated" }, 409);
    await db.prepare("UPDATE room_seat SET handle = ?2 WHERE room_id = ?1")
      .bind(id, h ? "@" + h : null).run();
    return json(roomView(await roomRows(db), now, id));
  }

  /* ---- 着席・移動 ---- */
  if (act !== "sit") return json({ error: "bad-act" }, 400);

  const seat = Number(body.seat);
  if (!Number.isInteger(seat) || seat < 1 || seat > ROOM_SEATS) return json({ error: "bad-seat" }, 400);

  const pub  = roomPub(body.pub) || (mineRow && mineRow.pub) || null;
  const hdl  = roomHandle(body.handle);
  if (hdl === undefined) return json({ error: "bad-handle" }, 400);
  const handle = hdl ? "@" + hdl : (mineRow ? mineRow.handle : null);
  const tier   = roomTier(body.tier) || (mineRow && mineRow.tier) || null;
  const rp     = roomRp(body.rp);

  const rows   = await roomRows(db);
  const target = rows.find(r => r.seat_no === seat);

  if (target && target.room_id === id) {
    /* 自分の席をもう一度タップした場合は在室の更新だけ */
    await db.prepare("UPDATE room_seat SET last_seen=?2, tier=?3, rp=?4 WHERE room_id=?1")
      .bind(id, now, tier, rp).run();
    return json(roomView(await roomRows(db), now, id));
  }
  /* 在室中の人の席は奪えない */
  if (target && (now - target.last_seen) < ROOM_LIVE_MS) return json({ error: "taken", seat }, 409);

  const st = [];
  if (mineRow) {
    /* seat_no に UNIQUE があるので、いったん負の番号へ逃がしてから入れ替える */
    st.push(db.prepare("UPDATE room_seat SET seat_no = ?2 WHERE room_id = ?1").bind(id, -mineRow.seat_no));
    if (target) {
      /* ゴーストを上書きせず、自分が今いた席へ移す */
      st.push(db.prepare("UPDATE room_seat SET seat_no = ?2 WHERE room_id = ?1").bind(target.room_id, mineRow.seat_no));
    }
    st.push(db.prepare(
      "UPDATE room_seat SET seat_no=?2, pub=?3, handle=?4, tier=?5, rp=?6, last_seen=?7 WHERE room_id=?1"
    ).bind(id, seat, pub, handle, tier, rp, now));
  } else {
    if (target) {
      /* 自分の席がまだ無い場合は、空いている番号へゴーストを退避。
         空きが無ければ、いずれ4時間で消える行なのでここで手放す。 */
      const used = new Set(rows.map(r => r.seat_no));
      let free = 0;
      for (let i = 1; i <= ROOM_SEATS; i++) if (!used.has(i)) { free = i; break; }
      st.push(free
        ? db.prepare("UPDATE room_seat SET seat_no = ?2 WHERE room_id = ?1").bind(target.room_id, free)
        : db.prepare("DELETE FROM room_seat WHERE room_id = ?1").bind(target.room_id));
    }
    st.push(db.prepare(
      "INSERT INTO room_seat (room_id, seat_no, pub, handle, tier, rp, last_seen) VALUES (?1,?2,?3,?4,?5,?6,?7)"
    ).bind(id, seat, pub, handle, tier, rp, now));
  }

  try {
    await db.batch(st);   // batch は1トランザクション。途中で落ちれば元に戻る
  } catch (e) {
    /* UNIQUE 違反 = 読んでから書くまでの間に他の人が座った */
    if (String(e.message || e).indexOf("UNIQUE") >= 0) return json({ error: "taken", seat }, 409);
    throw e;
  }
  return json(roomView(await roomRows(db), now, id));
}

function json(obj, status = 200, maxAge = 0) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": maxAge ? `public, max-age=${maxAge}` : "no-store"
    }
  });
}

function cors(res, origin) {
  const h = new Headers(res.headers);
  if (STRICT_ORIGINS.length === 0) {
    h.set("Access-Control-Allow-Origin", "*");
  } else if (origin && STRICT_ORIGINS.includes(origin)) {
    h.set("Access-Control-Allow-Origin", origin);
    h.set("Vary", "Origin");
  } else {
    h.set("Access-Control-Allow-Origin", STRICT_ORIGINS[0]);
    h.set("Vary", "Origin");
  }
  h.set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  h.set("Access-Control-Allow-Headers", "Content-Type");
  h.set("Access-Control-Max-Age", "86400");
  return new Response(res.body, { status: res.status, headers: h });
}
